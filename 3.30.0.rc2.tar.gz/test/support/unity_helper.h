#ifndef UNITY_HELPER
#define UNITY_HELPER

#define UNITY_TEST_ASSERT_EQUAL_rd_sensor_data_t(expected, actual, line, message)
#define UNITY_TEST_ASSERT_EQUAL_app_log_read_state_t(expected, actual, line, message)
#endif