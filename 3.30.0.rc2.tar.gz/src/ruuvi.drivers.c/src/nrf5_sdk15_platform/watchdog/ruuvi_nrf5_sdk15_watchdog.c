#include "ruuvi_driver_enabled_modules.h"
#include "ruuvi_interface_watchdog.h"
#if RUUVI_NRF5_SDK15_WATCHDOG_ENABLED
#include "ruuvi_driver_error.h"
#include "ruuvi_nrf5_sdk15_error.h"
#include "ruuvi_interface_log.h"
#include "ruuvi_interface_power.h"
#include "ruuvi_task_led.h"
#include "nrf_drv_clock.h"
#include "nrf_drv_wdt.h"
#include <stdbool.h>

nrf_drv_wdt_channel_id m_channel_id;
wdt_evt_handler_t      m_on_trigger;

/**
 * @brief WDT events handler.   DG12 adds unluck blinking LED  01/17/21
 */
void wdt_event_handler (void)
{
    //NOTE: The max amount of time we can spend in WDT interrupt is two cycles of 32768[Hz] clock - after that, reset occurs
    if (NULL != m_on_trigger) { m_on_trigger(); }
    ri_watchdog_feed();
    char lmsg[128];
    snprintf(lmsg,  sizeof (lmsg), " \r\n\n  %8d   --  WDT Triggered, reset\r\n", (int)ri_rtc_millis ());
    ri_log (RI_LOG_LEVEL_ERROR, lmsg);
    for ( int16_t i=0; i<13; i++) { rt_led_activity_indicate(true); ; ri_delay_ms(500u);
                                       rt_led_activity_indicate(false) ; ri_delay_ms(500u);      // ri allows yield!
                                       ri_watchdog_feed();                                    }


    while (1);
}

/**
 * @param Initializes watchdog module.
 * After initialization watchdog must be fed at given interval or the program will reset.
 * There is no way to uninitialize the watchdog.
 * Consider bootloader watchdog interval on setup.
 *
 * @param[in] interval How often the watchdog should be fed.
 * @param[in] handler Function called on watchdog trigger. Must complete within 2 1/2^15 ms cycles.
 *
 * @retval RD_SUCCESS on success.
 * @retval RI_ERROR_INVALID_STATE if Watchdog is already initialized.
 */
rd_status_t ri_watchdog_init (const uint32_t interval_ms, const wdt_evt_handler_t handler)
{
    uint32_t err_code = NRF_SUCCESS;
    nrf_drv_wdt_config_t config = NRF_DRV_WDT_DEAFULT_CONFIG;
    config.reload_value = interval_ms;
    err_code = nrf_drv_wdt_init (&config, wdt_event_handler);

    if (NRF_SUCCESS == err_code)
    {
        err_code = nrf_drv_wdt_channel_alloc (&m_channel_id);

        if (NRF_SUCCESS == err_code)
        {
            nrf_drv_wdt_enable();

            // Halting the LFCLK while WDT is running hangs the program.
            // Request LFCLK to make sure it's never stopped after this point.
            // https://devzone.nordicsemi.com/f/nordic-q-a/45584/softdevice-hangs-forever-during-disable-while-stopping-lfclk
            // Initialize clock if not already initialized
            if (false == nrf_drv_clock_init_check())
            {
                err_code |= nrf_drv_clock_init();
            }

            nrf_drv_clock_lfclk_request (NULL);
        }
    }

    m_on_trigger = handler;
    return ruuvi_nrf5_sdk15_to_ruuvi_error (err_code);
}

/**
 * "Feed" the watchdog, resets the watchdog timer.
 * This must be called after watchdog initialization or the program will reset.
 */
rd_status_t ri_watchdog_feed (void)
{
    nrf_drv_wdt_channel_feed (m_channel_id);
    return RD_SUCCESS;
}

#endif
