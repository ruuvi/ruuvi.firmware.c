/*   to do
#include "ruuvi_driver_enabled_modules.h"
#include "ruuvi_interface_log.h"

#include "nrf_log.h"                  //     NRF_LOG_LEVEL should be most detailed
#include "nrf_log_default_backends.h" // NRF_LOG_DEFAULT_BACKENDS_INIT() nrf_log_default_backends_init() protype only
#include "nrf_log_ctrl.h"
#define NRF_LOG_LEVEL 4               // default to DEBUG since Nordic generates code

*/
/**
* @file ruuvi_nrf5_sdk15_log.h
* @author Otso Jousimaa <otso@ojousima.net>
* @date 2021-01-28
* @copyright Ruuvi Innovations Ltd, license BSD-3-Clause.
* @brief Header to enable and disable module compilation.


    Saving space is not a consideration as if it fits with debugging it will surely fit in production

    
*/

