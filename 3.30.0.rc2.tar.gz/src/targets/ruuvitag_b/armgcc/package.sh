#!/bin/bash
echo +++++++++++++++++++++++++++++++++ $0 $* +++++++++++++++++++++++  # make and nrfutil are so noisey show where we start
cd "$(dirname "$0")"
pwd             # show where we are
ls -ltra        # show what we start with
ls -ltra _build

TARGET=ruuvitag_b
NAME="ruuvifw"

echo "  check that _build/nrf52832_xxaa.hex exists"
if [ -f  _build/nrf52832_xxaa.hex ]; then
   ls -l _build/nrf52832_xxaa.hex
else
   echo -- _build/nrf52832_xxaa.hex does not exist,  $0 aborting; exit 1
fi

echo " ++ If git is not configured the following may report "
echo " ++      fatal: No names found, cannot describe anything.   -OR-"
echo " ++      fatal: Not a git repository (or any of the parent directories): "
echo " ++ This is OK"
VERSION=$(git describe --exact-match --tags HEAD)
if [ -z "$VERSION" ]; then
  VERSION=$(git rev-parse --short HEAD)     #  ugly like  a1db209
fi

while getopts "n:v:" option;    # call with    -n to set NAME ;  -v to set version 
do
case "$option"
in
n) NAME=$OPTARG;;
v) VERSION=$OPTARG;;
esac
done

BINNAME=$TARGET\_armgcc\_$NAME\_$VERSION       # underscores after $VARIABLES must be escaped     
echo BINNAME: $BINNAME
BOOTLOADER="ruuvitag_b_s132_6.1.1_bootloader_3.1.0.hex"     # same for all TARGETs
if [ -f  $BOOTLOADER ]; then
   ls -l $BOOTLOADER
else
   echo ++  wget  $BOOTLOADER from github                              3.1.0-beta/ruuvitag_b_s132_6.1.1_bootloader_3.1.0.hex
   wget https://github.com/ruuvi/ruuvi.nrf5_sdk15_.c/releases/download/3.1.0-beta/ruuvitag_b_s132_6.1.1_bootloader_3.1.0.hex
   rc=$?;if [ $rc -ne 0 ]; then echo -- $0 aborting; exit $rc ;fi
fi

key="ruuvi_open_private.pem"     
if [ -f  $key ]; then
   ls -l $key
else
   echo ++ wget $key ruuvi_open_private.pem from github
   wget https://github.com/ruuvi/ruuvi.nrf5_sdk15_.c/releases/download/3.0.0/ruuvi_open_private.pem
   rc=$?;if [ $rc -ne 0 ]; then echo -- $0 aborting; exit $rc ;fi
fi

# softdevice name is ugly copy it here and use local name This also captures the softdevice used for regression analysis
if [ -f  softdevice.hex ]; then
   ls -l softdevice.hex
else
   echo ++ wget $key ruuvi_open_private.pem from github
cp -v ../../../../nRF5_SDK_15.3.0_59ac345/components/softdevice/s132/hex/s132_nrf52_6.1.1_softdevice.hex softdevice.hex
fi

echo ++ rm   older versions
rm -v -f   $TARGET\_armgcc*$NAME*     #  -f do not complain it there are none

# on mac os /Library/Python/2.7/site-packages/nordicsemi/nrfutil       /Applications/Nordic Semiconductor has mergehex 
echo ++ nrfutil setting generate from  _build/nrf52832_xxaa.hex
nrfutil settings generate --family NRF52 --application _build/nrf52832_xxaa.hex --application-version 1  \
                                                                                --bootloader-version  1  \
                                                                                --bl-settings-version 1     settings.hex 
rc=$?;if [ $rc -ne 0 ]; then echo -- $0 aborting; exit $rc ;fi

echo ++ mergehex -m softdevice     $BOOTLOADER     settings            -o sbc.hex
./mergehex973 -m         softdevice.hex $BOOTLOADER     settings.hex        -o sbc.hex
rc=$?;if [ $rc -ne 0 ]; then echo -- $0 aborting; exit $rc ;fi

echo ++ mergehex -m sbc            nrf52832_xxaa.hex                                              -o $BINNAME_full.hex
./mergehex973 -m sbc.hex         _build/nrf52832_xxaa.hex                                              -o $BINNAME\_full.hex
rc=$?;if [ $rc -ne 0 ]; then echo -- $0 aborting; exit $rc ;fi

echo ++ pkg generate                      nrf52832_xxaa.hex  to                                   $BINNAME_dfu_app.zip
nrfutil pkg generate --application _build/nrf52832_xxaa.hex --application-version 1 --hw-version 0xB0 \
                     --sd-req 0xB7 \
                     --key-file ruuvi_open_private.pem                                             $BINNAME\_dfu_app.zip
rc=$?;if [ $rc -ne 0 ]; then echo -- $0 aborting; exit $rc ;fi

#--sd-id 0xB7 ?????
echo ++ pkg generate                       nrf52832_xxaa.hex  include  and softdevice  to  $BINNAME_sdk12.3_to_15.3_dfu.zip
nrfutil pkg generate --application _build/nrf52832_xxaa.hex --application-version 1 --hw-version 0xB0 \
                     --bootloader  $BOOTLOADER --bootloader-version 2 \
                     --sd-req 0x91,0xAF,0xB7 \
                     --softdevice softdevice.hex  \
                     --key-file ruuvi_open_private.pem    --debug-mode                     $BINNAME\_sdk12.3_to_15.3_dfu.zip 
rc=$?;if [ $rc -ne 0 ]; then echo -- $0 aborting; exit $rc ;fi
                       

cp -v _build/nrf52832_xxaa.map     $BINNAME\_app.map    # move to targetname 
if [ $? -ne 0 ]; then echo " -- where is the map ?"; fi
cp -v _build/nrf52832_xxaa.hex     $BINNAME\_app.hex
ls -ltra   *.hex *.zip *.map        # show what we have now
