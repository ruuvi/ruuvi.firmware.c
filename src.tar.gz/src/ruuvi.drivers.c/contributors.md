Contributors, in alphabetical order. Real name and email are included if they're listed
on GH profile page.

| GitHub Nick   | Real Name     | Email             |
|:------------- |:------------- |:----------------- |
| mdxs          | -             | -                 |
| ojousima      | Otso Jousimaa | otso@ojousima.net |
| peltsu        | -             | -                 |
